#include "GameEngine.hh"

//Screen dimension constants
#define SCREEN_WIDTH  640
#define SCREEN_HEIGHT  480

//Hola aquest es el bo


int main(int argc, char* args[]) {

	Run("Snake by Ferran and Marc", SCREEN_WIDTH, SCREEN_HEIGHT);

	return 0;
}

