#pragma once

#define GRID_WIDTH 64
#define GRID_HEIGHT 48

struct COOR {
	int x;
	int y;

	//bool operator ==() {}
};