#pragma once
#include <SDL\SDL.h>
using namespace std;

//class TM
